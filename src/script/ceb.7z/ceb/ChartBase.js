﻿class ChartBase {
    constructor() {
        Highcharts.getOptions().colors = ['#00Aeef', '#f4b213', '#9cc84b', '#2bc4b6', '#8d64aa', '#0a3f6b', '#aa5019', '#416428', '#00566b', '#46295b', '#7fd6f7', '#f9d889', '#cde3a5', '#95e1da', '#c6b1d4'];

    }

    width(_x) {
        if (!arguments.length) return this._width;
        this._width = _x;
        return this;
    }

    height(_y) {
        if (!arguments.length) return this._height;
        this._height = _y;
        return this;
    }

    renderTo(_id) {
        if (!arguments.length) return this._renderTo;
        this._renderTo = _id;
        return this;
    }

    displayName(_val) {
        if (!arguments.length) return this._displayName;
        this._displayName = _val;
        return this;
    }

    category(_val) {

        if (!arguments.length) return this._category;
        this._category = _val;
        return this;
    }

    seriesData(_val) {

        if (!arguments.length) return this._seriesData;
        this._seriesData = _val;
        return this;
    }

    plot() {
        //'The plot function has not been defined.'
    }

    title(_val) {
        if (!arguments.length) return this._title;
        this._title = _val;
        return this;
    }

    subtitle(_val) {

        if (!arguments.length) return this._subtitle;
        this._subtitle = _val;
        return this;
    }
}

class BarChart extends ChartBase {
    constructor() {
        super();
    }

    plot() {
        const chart = new Highcharts.Chart({
            chart: {
                renderTo: this.renderTo(this),
                defaultSeriesType: 'column',
                width: this.width(this),
                height: this.height(this),
                marginTop: 40,
                backgroundColor: '#ffffff'
            },
            title: {
                text: ''
            },
            xAxis: {
                categories: this.category(this),
                tickWidth: 0,
                labels: {
                    style: {
                        fontSize: '11px',
                        fontFamily: 'Arial',
                        fontWeight: 'normal',
                        color: '#333333'
                    }
                }
            },
            yAxis: {
                min: 0,
                gridLineColor: '#E2E2E2',
                gridLineWidth: 1,
                gridLineDashStyle: 'Solid',
                title: {
                    text: '',
                    style: {
                        fontSize: '12px',
                        fontFamily: 'Arial',
                        fontWeight: 'normal',
                        color: '#333333'
                    }
                },
                labels: {
                    style: {
                        fontSize: '12px',
                        fontFamily: 'Arial',
                        fontWeight: 'normal',
                        color: '#939598'
                    }
                }
            },
            legend: {
                floating: false,
                borderRadius: 0,
                borderWidth: 0,
                shadow: false,
                enabled: true,
                backgroundColor: '#ffffff',
                itemStyle: {
                    fontSize: '12px',
                    fontFamily: 'Arial',
                    fontWeight: 'normal',
                    color: '#939598'
                }
            },
            tooltip: {
                style: {
                    fontSize: '13px',
                    fontFamily: 'Arial',
                    color: '#333333',
                    fontWeight: 'bold'
                },
                borderColor: '#c2c2c2',
                backgroundColor: '#ffffff',
                borderRadius: 3,
                borderWidth: 2,
                shadow: false,
                formatter() {
                    return Highcharts.numberFormat(this.y, 0);
                }
            },
            plotOptions: {
                series: {
                    shadow: false
                },
                column: {
                    borderWidth: 0,
                    bordorColor: '#ffffff',
                    pointPadding: 0,
                    dataLabels: {
                        enabled: false,
                        rotation: 270,
                        y: -25,
                        x: 2,
                        style: {
                            color: '#333333',
                            fontSize: '12px',
                            fontFamily: 'Arial'
                        },
                        formatter() {
                            return Highcharts.numberFormat(this.y, 0);
                        }
                    }
                }
            },
            series: this.seriesData(this),
            navigation: {
                buttonOptions: {
                    align: 'right',
                    backgroundColor: 'white',
                    height: 17,
                    width: 20,
                    symbolSize: 10,
                    symbolX: 10,
                    symbolY: 8,
                    symbolStrokeWidth: 1,
                    symbolStroke: '#364F6A'
                }
            },
            credits: {
                enabled: false,
                href: "http://www.executiveboard.com/",
                text: "www.executiveboard.com"
            }
        });

    }
}

      
// alert(BarChart.prototype instanceof ChartBase)    
module.exports =BarChart