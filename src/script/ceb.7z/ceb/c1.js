
var barchart = new BarChart();
            barchart.width(960).height(300).renderTo('data')
                    .seriesData([{ name: 'Year 1800', data: [107, 31, 635, 203, 2] }]).plot();
module.exports =C1